<?php $__env->startComponent('mail::message'); ?>
    <div id="resetPassword">
        <h3 class="title type01">Reset Password</h3>

        <p class="body type01">Hi, <?php echo e($receiver ? $receiver->email : ""); ?>.</p>

        <p class="body type01">
            [<?php echo e(config("app.name")); ?>] To reset your password, click the Reset Password button.
        </p>

        <div class="btns" style="text-align:center;">
            <a href="<?php echo e($passwordReset ? $passwordReset->resetUrl() : ''); ?>" class="btn type01 width-100 bg-primary">Reset Password</a>
        </div>
    </div>
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\project\Wharton High School\개발\wharton\resources\views/emails/passwordResets/created.blade.php ENDPATH**/ ?>