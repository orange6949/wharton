<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
    <title><?php echo e(config("app.name")); ?></title>
    <link href="<?php echo e(asset('css/default.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/aos-2.3.1.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/animate.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/swiper.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/module.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" />
    <script src="<?php echo e(asset('js/jquery-1.7.1.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/swiper.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/aos-2.3.1.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/common.js')); ?>" defer></script>
    <script src="<?php echo e(mix('/js/app.js')); ?>" defer></script>
</head>
<body>
<div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div>
</body>
</html>
<?php /**PATH D:\project\Wharton High School\개발\wharton\resources\views/app.blade.php ENDPATH**/ ?>