<footer class="footer">
    <?php echo e(Illuminate\Mail\Markdown::parse($slot)); ?>

</footer>
<?php /**PATH D:\project\Wharton High School\개발\wharton\resources\views/vendor/mail/html/footer.blade.php ENDPATH**/ ?>