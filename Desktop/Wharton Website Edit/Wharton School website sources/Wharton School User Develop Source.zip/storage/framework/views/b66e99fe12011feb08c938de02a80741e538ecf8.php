<?php echo e($slot); ?>

<?php /**PATH D:\project\Wharton High School\개발\wharton\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>