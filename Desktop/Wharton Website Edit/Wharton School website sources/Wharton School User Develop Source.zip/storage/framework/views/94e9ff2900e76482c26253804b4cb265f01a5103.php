<header class="header">
    <a href="<?php echo e(config("app.url")); ?>" style="color:#fff;">
        <!-- <img src="/img/logo.png" alt=""> -->
        <?php echo e(config("app.name")); ?>

    </a>
</header>
<?php /**PATH D:\project\Wharton High School\개발\wharton\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>