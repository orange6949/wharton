<?php

return [
    "invalid" => "유효하지 않은 계정정보입니다.",
    "passwordReset" => [
        "send_success" => "비밀번호 초기화 메일이 발송되었습니다.",
        "send_fail" => "비밀번호 초기화 메일 발송에 실패하였습니다.",
        "send" => "비밀번호 초기화 메일이 발송되었습니다.",
        "reset_success" => "비밀번호가 초기화되었습니다.",
        "reset_fail" => "비밀번호 초기화에 실패하였습니다.",
    ]
];
