<?php

return [
    "invalid" => "This is not valid account information.",
    "passwordReset" => [
        "send_success" => "Success to send email.",
        "send_fail" => "Fail to send email.",
        "send" => "Reset Password Mail arrived.",
        "reset_success" => "Success to reset password.",
        "reset_fail" => "Fail to reset password."
    ]
];
