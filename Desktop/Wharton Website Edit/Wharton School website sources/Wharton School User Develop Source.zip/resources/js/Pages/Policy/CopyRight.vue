<template>
    <div>
        <div class="subVisual">
            <h3 class="title">CopyRight</h3>
            <img src="/img/subVisual06.jpg" alt="">
        </div>

        <div class="subContent area-policy">
            <div class="wrap">
                <div class="m-policy type01">

                    <div class="content">
                        <h3 class="bigTitle">
                            The Picture's Copyright
                        </h3>

                        <section class="section">
                            <p class="body">
                                Some pictures used at this website come from the Internet, and the copyright is owned
                                by the original creator. If there are any infringements of using the picture, please contact
                                us to handle or take it off.
                            </p>
                        </section>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    mounted(){
        AOS.init();
    }
}
</script>
