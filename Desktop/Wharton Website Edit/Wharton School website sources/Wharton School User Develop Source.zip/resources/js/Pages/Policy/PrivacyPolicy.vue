<template>
    <div>
        <div class="subVisual">
            <h3 class="title">Privacy Policy</h3>
            <img src="/img/subVisual06.jpg" alt="">
        </div>

        <div class="subContent area-policy">
            <div class="wrap">
                <div class="m-policy type01">
                    <div class="content">
                        <h3 class="bigTitle">
                            Web Privacy Policy
                        </h3>


                        <section class="section">
                            <p class="body">
                                Wharton School, hereinafter the CONTROLLER, is responsible for the processing of the user’s data and informs them that the data will be processed following the provisions of Regulation (EU) 2016/679 of 27 April 2016 (GDPR) on the protection of individuals concerning the processing of personal data and on the free movement of such data. Therefore, the CONTROLLER provides the following information to the user regarding the processing of user data:
                            </p>
                            <p class="body">
                                Purpose of the processing: to maintain a commercial relationship with the user. The planned processing operations are:
                                Sending commercial advertising communications by email, fax, SMS, MMS, social communities, or by
                                any other electronic or physical means, present or future that makes it possible to carry out commercial
                                communications. These communications will be made by the CONTROLLER and will be related to their
                                products and services or those of their partners or suppliers with whom they have reached an agreement.
                                In this case, the third parties will never have access to personal data.
                            </p>
                            <p class="body">
                                Conducting statistical studies.
                            </p>
                            <p class="body">
                                Processing orders, queries, or any request made by the user through any of the available contact methods.
                            </p>
                            <p class="body">
                                Sending newsletters.
                            </p>
                            <p class="body">
                                For users who are current, former, or prospective students of an education institution operated by
                                CONTROLLER: In furtherance of the legitimate interest of CONTROLLER, CONTROLLER shall
                                engage in the collection and retention of student data that is standard and typical for a school to collect
                                and retain for a student’s admission into, and progression through, an academic program, including but
                                not limited to such information as the student names, dates and locations of birth, grade levels, gender
                                information, nationalities, native languages, e-mail address(es), phone number(s), video/voice chat screen
                                names, prospective graduation dates, parents’ names and contact information, home schools, academic
                                history and performance data from home school programs (including homeschool transcript information),
                                academic performance/grades in
                            </p>
                            <p class="body">
                                CONTROLLER’s academic program, and other information pertaining to a student's tenure in
                                <br/>CONTROLLER’s academic program.
                            </p>
                            <p class="body">
                                Legal basis of the processing: The Data Subject's consent; legitimate interest of CONTROLLER to
                                provide educational services and keep student records for the purposes of running an educational
                                institution.

                            </p>
                            <p class="body">
                                Data storage criteria: Data will be stored while there is a mutual interest in maintaining the data or to the
                                extent that CONTROLLER has a legitimate interest to provide educational services and/or keep student
                                records of operating an educational institution unless overridden by the interests or fundamental rights
                                and freedoms of the User which require protection of personal data. When such a goal is no longer


                            </p>
                            <p class="body">
                                necessary, the data will be erased with adequate security measures to ensure the pseudonymization or the
                                complete destruction of the data. Data disclosure: The data will not be disclosed to third parties unless
                                legally required. Rights of the User:


                            </p>
                            <p class="body">
                                Right to withdraw consent at any time.


                            </p>
                            <p class="body">
                                Right of access, rectification, portability, and erasure of their data and the restriction or


                            </p>
                            <p class="body">
                                objection to their processing, with such rights limited to the extent that CONTROLLER maintains a
                                legitimate interest to provide training services and keep student records to run an educational institution
                                unless overridden by the interests or fundamental rights and freedoms of the User which require
                                protection of personal data.


                            </p>
                            <p class="body">
                                The right to file a claim with the appropriate governmental organization if you consider that the
                                processing does not comply with prevailing law.

                            </p>
                            <p class="body">
                                Contact information for exercising rights: E-mail: support@wharton.education

                            </p>
                        </section>

                        <section class="section">
                            <h3 class="title">
                                1. COMPULSORY OR OPTIONAL NATURE OF THE INFORMATION PROVIDED BY THE USER
                            </h3>

                            <p class="body">
                                The Users, by marking the corresponding boxes and entering data in the fields, marked with an asterisk
                                (*) in the contact form or download forms, accept expressly and in a free and unequivocal way that their
                                data are necessary for the supplier to meet their request, voluntarily providing their data in the remaining
                                fields. The User ensures that the personal data provided to the CONTROLLER are accurate and are
                                responsible for communicating any changes to them.

                            </p>
                            <p class="body">
                                The CONTROLLER informs and expressly ensures users that their data will not be transferred to third
                                parties under any circumstances, except to authorized processors under applicable privacy law, or with the
                                express, informed, and unequivocal consent of the Users. All data requested through the website are
                                mandatory, as they are necessary for the provision of services to the User
                            </p>
                        </section>

                        <section class="section">
                            <h3 class="title">2. SECURITY MEASURES</h3>

                            <p class="body">
                                That following the provisions of the current regulations on the protection of personal data, the
                                CONTROLLER is complying with all the provisions of the GDPR regulations for processing the personal
                                data for which they are responsible and is manifestly complying with the principles described in Article 5
                                of the GDPR, by which they are processed in a lawful, fair and transparent manner to the data subject and
                                appropriate, relevant and limited to what is necessary for relation to the purposes for which they are
                                processed.

                            </p>
                            <p class="body">
                                The CONTROLLER guarantees that all appropriate technical and organizational policies have been
                                implemented to apply the security measures established by the GDPR to protect the rights and freedoms
                                of Users and has communicated the appropriate information for them to be able to exercise their rights
                                and freedoms.
                            </p>
                        </section>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    mounted(){
        AOS.init();
    }
}
</script>
