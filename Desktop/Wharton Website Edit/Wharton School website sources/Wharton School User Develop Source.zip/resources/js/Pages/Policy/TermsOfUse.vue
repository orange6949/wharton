<template>
    <div>
        <div class="subVisual">
            <h3 class="title">Terms of use</h3>
            <img src="/img/subVisual06.jpg" alt="">
        </div>

        <div class="subContent area-policy">
            <div class="wrap">
                <div class="m-policy type01">
                    <div class="content">
                        <h3 class="bigTitle">
                            World Cultures & Languages Institute Terms of Use
                        </h3>

                        <section class="section">
                            <p class="body">
                                By using the World Cultures & Languages Institute website ("Site"), you agree to follow
                                and be bound by these terms of use ("Terms of Use") and the Privacy Policy which are
                                hereby incorporated into these Terms of Use. In these Terms of Use, the words "you"
                                and "your" refer to each Site visitor or user, "we, " "us", and "our" refer to World Cultures
                                & Languages Institute, and "Services" refers to all services provided by us.
                                We may revise these Terms of Use at any time without notice to you. It is your
                                responsibility to review these Terms of Use periodically. If at any time you find these
                                Terms of Use unacceptable or if you do not agree to these Terms of Use, please do not
                                use this Site. If you have any questions about these Terms of Use, please contact us at
                                support@wharton.education.

                            </p>
                            <p class="body">
                                YOU AGREE THAT BY USING THE SITE AND THE SERVICES, YOU ARE AT LEAST
                                18 YEARS OF AGE OR, IF THE USER IS A MINOR, THE USER HAS THE CONSENT
                                OF A PARENT OR LEGAL GUARDIAN TO USE THIS SITE. FOR THE AVOIDANCE
                                OF DOUBT, MINORS WILL NOT HAVE ACCESS TO THE INTERACTIVE PORTIONS
                                OF THIS SITE WITHOUT REGISTRATION AND CONSENT FROM A PARENT OR
                                LEGAL GUARDIAN. BY SUBMITTING SUCH REGISTRATION, YOU CONFIRM THAT
                                YOU ARE LEGALLY ABLE TO ENTER INTO A CONTRACT AND AGREE TO COMPLY
                                WITH ALL APPLICABLE LAWS AND REGULATIONS.

                            </p>
                            <p class="body">
                                1. Privacy Policy. World Cultures & Languages Institute respects your privacy and
                                permits you to control the treatment of your personal information. A complete statement
                                of World Cultures & Languages Institute's current Privacy Policy can be found by
                                clicking here. World Cultures & Languages Institute's Privacy Policy is expressly
                                incorporated into this Terms of Use. When you open an account to use or access
                                certain portions of the Site or the Services, you must provide complete and accurate
                                information as requested on the registration form. You will also be asked to provide a
                                username and password. If you choose to register, you agree to (a) supply the
                                information requested in the registration process, (b) ensure that all the information you
                                supply to us is accurate, and (c) update your personal information. You are entirely
                                responsible for maintaining the confidentiality of your password. You may not use a third
                                party's account, username, or password at any time. You agree to notify World Cultures
                                & Languages Institute immediately of any unauthorized use of your account, username,
                                or password. World Cultures & Languages Institute shall not be liable for any losses you
                                incur as a result of someone else's use of your account or password, either with or
                                without your knowledge. You may be held liable for any losses incurred by World
                                Cultures & Languages Institute, our affiliates, officers, directors, employees,
                                consultants, agents, and representatives due to someone else's use of your account or
                                password. In connection with the use of certain World Cultures & Languages Institute
                                products or Services, you may be asked to provide personal information in a
                                questionnaire, application, form or similar document or service. This information will be
                                protected pursuant to our Privacy Policy. In addition, you grant World Cultures &
                                Languages Institute a worldwide, royalty-free, non-exclusive, and fully sub-licensable
                                license to use, distribute, reproduce, modify, publish and translate this personal
                                information solely for the purpose of enabling your use of the applicable service. You
                                may revoke this license and terminate World Cultures & Languages Institute's rights at
                                any time by removing your personal information from the applicable service.

                            </p>
                            <p class="body">
                                1. Ownership. This Site is owned and operated by World Cultures & Languages
                                Institute. All right, title and interest in and to the materials provided on this Site, including
                                but not limited to information, documents, logos, graphics, sounds, and images (the
                                "Materials"), are owned or licensed either by World Cultures & Languages Institute or by
                                our respective third party authors, developers or vendors. Except as may be expressly
                                stated on the Site or in these Terms of Use, none of the Materials may be copied,
                                reproduced, republished, downloaded, uploaded, posted, displayed, transmitted or
                                distributed in any way, and nothing on this Site shall be construed to confer any license
                                under any of World Cultures & Languages Institute's intellectual property rights, whether
                                by estoppel, implication or otherwise. See the "Contact Information" below if you have
                                any questions about obtaining such licenses. World Cultures & Languages Institute
                                does not sell, license, lease, or otherwise provide any of the Materials other than those
                                specifically identified as being provided by World Cultures & Languages Institute. Any
                                rights not expressly granted herein are reserved by World Cultures & Languages
                                Institute.

                            </p>
                            <p class="body">
                                2. Limited Permission to Download. World Cultures & Languages Institute hereby grants
                                you permission to download, view, copy and print the Materials found on World Cultures
                                & Languages Institute on any single, stand-alone computer solely for your personal,
                                informational, and internal business use provided that (i) the copyright and trademark
                                notice appearing below appears in such Materials, (ii) the Materials are not used on any
                                other Web site or in a networked computer environment and (iii) the Materials are not
                                modified in any way. This permission terminates automatically without notice if you
                                breach any of the terms or conditions of these Terms of Use. On any such termination,
                                you agree to destroy any downloaded or printed Materials immediately. Any
                                unauthorized use of any Materials contained on this Site may violate copyright laws,
                                trademark laws, laws of privacy and publicity, communications regulations and statutes,
                                as well as other rights, laws, rules, regulations, and statutes.

                            </p>
                            <p class="body">
                                3. Links to Third Party Sites. This Site may contain links to Web sites controlled by
                                parties other than World Cultures & Languages Institute. World Cultures & Languages
                                Institute may work with a number of partners and affiliates whose sites are linked with
                                World Cultures & Languages Institute. Both World Cultures & Languages Institute is not
                                responsible for and does not endorse or accept any responsibility for the availability,
                                contents, products, services, or use of any Third Party Site, any Website accessed from
                                a Third Party Site, or any changes or updates to such sites. World Cultures &
                                Languages Institute makes no guarantees about the content or quality of the products
                                or services provided by such sites. World Cultures & Languages Institute is not
                                responsible for webcasting or any other form of transmission received from any Third
                                Party Site. World Culture & Language Institute is providing these links to you only as a
                                convenience, and the inclusion of any link does not imply endorsement by World
                                Cultures & Languages Institute of the Third Party Site. You acknowledge that you bear
                                all risks associated with access to and use of content provided on a Third Party Site and
                                agree that neither World Cultures & Languages Institute is responsible for any loss or
                                damage of any sort you may incur from dealing with a third party. You should contact
                                the site administrator for the applicable Third Party Site if you have any concerns
                                regarding such links or the content located on any such Third Party Site.

                            </p>
                            <p class="body">
                                4. Reviews, Comments, Communications, and Other Content. At various locations on
                                the Site, World Cultures & Languages Institute may permit visitors to post reviews,
                                comments, communications, and other content (the "User Content"). Contributions to,
                                access to and use of the User Content is at your own risk and subject to the below
                                terms and all other terms and conditions of these Terms of Use.

                            </p>
                            <div class="body">
                                5.1. Rights and Responsibilities of World Cultures & Languages Institute. World
                                Cultures & Languages Institute respects the intellectual property of others, and we ask
                                our users to do the same. World Cultures & Languages Institute may, in appropriate
                                circumstances and at its discretion,
                                disable and/or terminate the accounts of users who may be repeat infringers. If you
                                believe that your work has been copied in a way that constitutes copyright infringement,
                                or your intellectual property rights have been otherwise violated, please provide World
                                Cultures & Languages Institute's Copyright Agent with the following information:

                                <div class="bodies">
                                    <p class="body">
                                        An electronic or physical signature of the person authorized to act on behalf of
                                        the owner of the copyright or other intellectual property interest;

                                    </p>
                                    <p class="body">
                                        A description of the copyrighted work or other intellectual property that you claim
                                        has been infringed;

                                    </p>
                                    <p class="body">
                                        A description of where the material that you claim is infringing is located on the
                                        site;

                                    </p>
                                    <p class="body">
                                        Your address, telephone number, and email address;

                                    </p>
                                    <p class="body">
                                        A statement by you that you have a good faith belief that the disputed use is not
                                        authorized by the copyright owner, its agent, or the law;

                                    </p>
                                    <p class="body">
                                        A statement by you, made under penalty of perjury, that the above information in
                                        your notice is accurate and that you are the copyright or intellectual property
                                        owner or authorized to act on the copyright or intellectual property owner's
                                        behalf
                                    </p>
                                </div>
                            </div>
                            <p class="body">
                                World Cultures & Languages Institute's Agent for Notice of claims of copyright or other
                                intellectual property infringement can be reached as follows:

                            </p>
                            <p class="body">
                                By email: support@wharton.education

                            </p>
                            <p class="body">
                                World Cultures & Languages Institute is not the publisher or author of the User Content.
                                It is a passive service for storage and dissemination of the ideas and opinions that
                                World Cultures & Languages Institute members may choose to post and distribute as
                                User Content. World Cultures & Languages Institute does not screen works before they
                                are posted, and no prior approval is required for posting. World Cultures & Languages
                                Institute disclaims all copyright and ownership in such works and all responsibility for
                                them. Although we cannot make an absolute guarantee of system security, World
                                Cultures & Languages Institute takes reasonable steps to maintain security. If you have
                                reason to believe system security has been breached, contact us by
                                support@wharton.education for help. If World Cultures & Languages Institute's technical
                                staff finds that files or processes belonging to a member pose a threat to the proper
                                technical operation of the system or to the security of other members, World Cultures &
                                Languages Institute reserves the right to delete those files or to stop those processes. If
                                the World Cultures & Languages Institute technical staff suspects a username is being
                                used by someone who is not authorized by the proper user, World Cultures &
                                Languages Institute may disable that user's access in order to preserve system security.
                                In all such cases, World Cultures & Languages Institute will contact the member as
                                soon as feasible. World Cultures & Languages Institute has the right, in our sole and
                                absolute discretion, to (i) edit, redact or otherwise change any User Content, (ii)
                                re-categorize any User Content to place it in a more appropriate location or (iii)
                                pre-screen or delete any User Content that is determined to be inappropriate or
                                otherwise in violation of these Terms of Use, including but not limited to User Content
                                containing offensive language and advertisements. World Cultures & Languages
                                Institute reserves the right to refuse service to anyone and to cancel user access at any
                                time.

                            </p>
                            <p class="body">
                                5.2. Rights and Responsibilities of World Cultures & Languages Institute Users or Other
                                Posters of User Content. You are legally and ethically responsible for any User Content
                                - writings, files, pictures or any other work - that you post or transmit using any World
                                Cultures & Languages Institute service that allows interaction or dissemination of
                                information. In posting User Content, you are responsible for honoring the rights of
                                others, including intellectual-property rights (copyright, patent, and trademark), the right
                                to privacy and the right not to be labeled or slandered. For example, if you wish to post
                                a copyrighted work as User Content, you are responsible for first obtaining the copyright
                                holder's permission. Under United States federal law, you retain copyright on all works
                                you create and post as User Content unless you choose specifically to renounce it. By
                                posting such user content, you grant a license to World Cultures & Languages Institute
                                to use, reprint, distribute, modify, and create derivative works, which will be owned by
                                World Cultures & Languages Institute. In posting a work as User Content, you authorize
                                other members who have access to that service to make personal and customary use of
                                the work, including creating links or reposting, but not otherwise to reproduce or
                                disseminate it unless you give permission for such dissemination. You also give
                                permission to World Cultures & Languages Institute to copy your works as part of the
                                normal backup process. You have the right to remove any of your works from User
                                Content at any time. The use of your World Cultures & Languages Institute user
                                account or posting User Content for any illegal activity under the laws of the State of
                                New York and the United States is a violation of these Terms of Use. Since the law as to
                                the jurisdiction of online systems is unsettled, we urge you to consider the possible
                                effect of laws outside World Cultures & Languages Institute's locality or your own
                                residence. World Cultures & Languages Institute is open to members worldwide (and
                                works published on the World Wide Web, Usenet or other such services are accessible
                                to anyone on the Internet), and World Cultures & Languages Institute cannot guarantee
                                that you will not run into legal trouble in other jurisdictions over your posting. You agree
                                not use the Site in any way that could damage, disable, or impair any Services provided
                                World Cultures & Languages Institute (or the network(s) connected to the Site), violate
                                the privacy and security of other users or interfere with any user's use and enjoyment of
                                any of the Site. You agree not to attempt to gain unauthorized access to any services
                                offered on the Site, other accounts, computer systems or networks connected to the
                                Site, through hacking, password mining or any other means. You agree not to obtain or
                                attempt to obtain any materials or information through any means not intentionally made
                                available through the Site.

                            </p>
                            <p class="body">
                                5.3. Your Rights and Responsibilities as a World Cultures & Languages Institute User
                                and Reader of User Content.
                                If you have a complaint about the behavior or posts of another user, it is your
                                responsibility to attempt to resolve the conflict, typically by contacting that person
                                directly, if possible. Normally, World Cultures & Languages Institute staff will not take a
                                role in mediating conflicts between you and other users. World Cultures & Languages
                                Institute does not take responsibility for your behavior or that of other users. Your
                                access to the postings that users have posted as User Content is for your personal use
                                only. If you want to redistribute postings you find as User Content, it is your
                                responsibility to obtain permission from the poster (and any other person with rights in
                                such work).

                            </p>
                            <p class="body">
                                1. No Warranty.THE SITE AND ALL MATERIALS, DOCUMENTS OR FORMS
                                PROVIDED ON OR THROUGH YOUR USE OF THE SITE ARE PROVIDED ON AN
                                "AS IS" AND "AS AVAILABLE" BASIS. TO THE FULLEST EXTENT PERMITTED BY
                                LAW, WORLD CULTURES & LANGUAGES INSTITUTE EXPRESSLY DISCLAIMS ALL
                                WARRANTIES OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING BUT
                                NOT LIMITED TO IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
                                PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT. WORLD CULTURE &
                                LANGUAGE INSTITUTE MAKES NO WARRANTY THAT: (A) THE SITE OR THE
                                MATERIALS WILL MEET YOUR REQUIREMENTS; (B) THE SITE OR THE
                                MATERIALS WILL BE AVAILABLE ON AN UNINTERRUPTED, TIMELY, SECURE OR
                                ERROR-FREE BASIS; (C) THE RESULTS THAT MAY BE OBTAINED FROM THE USE
                                OF THE SITE, OR ANY MATERIALS OFFERED THROUGH THE SITE, WILL BE
                                ACCURATE OR RELIABLE; OR (D) THE QUALITY OF ANY PRODUCTS, SERVICES,
                                INFORMATION OR OTHER MATERIAL PURCHASED OR OBTAINED BY YOU
                                THROUGH THE SITE OR IN RELIANCE ON THE MATERIALS WILL MEET YOUR
                                EXPECTATIONS OR ARE SUITABLE FOR YOUR USE ANY MATERIALS THROUGH
                                THE USE OF THE SITE IS DONE AT YOUR OWN DISCRETION AND AT YOUR OWN
                                RISK. WORLD CULTURES & LANGUAGES INSTITUTE SHALL HAVE NO
                                RESPONSIBILITY FOR ANY DAMAGE TO YOUR COMPUTER SYSTEM OR LOSS
                                OF DATA THAT RESULTS FROM THE DOWNLOAD OF ANY CONTENT, MATERIALS,
                                INFORMATION OR SOFTWARE.

                            </p>
                            <p class="body">
                                2. Limitation of Liability. IN NO EVENT SHALL WORLD CULTURES & LANGUAGES
                                INSTITUTE, OUR OFFICERS, DIRECTORS, EMPLOYEES, AGENTS,
                                CONTRACTORS, SUPPLIERS, OR LICENSEES BE LIABLE FOR ANY INDIRECT,
                                PUNITIVE, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGE (INCLUDING
                                BUT NOT LIMITED TO LOSS OF BUSINESS, REVENUE, PROFITS, USE, DATA OR
                                OTHER ECONOMIC ADVANTAGE), HOWEVER IT ARISES, WHETHER IN AN
                                ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, OR
                                ARISING OUT OF OR IN CONNECTION WITH THE USE OR INABILITY TO USE THIS
                                SITE OR MATERIALS AVAILABLE FROM THIS SITE, EVEN IF WORLD CULTURES &
                                LANGUAGES INSTITUTE HAS BEEN PREVIOUSLY ADVISED OF THE POSSIBILITY
                                OF SUCH DAMAGE. IF YOUR USE OF MATERIALS FROM THIS SITE RESULTS IN
                                THE NEED FOR SERVICING, REPAIR OR CORRECTION OF EQUIPMENT OR DATA,
                                YOU ASSUME ANY COSTS THEREOF. SOME STATES DO NOT ALLOW THE
                                EXCLUSION OR LIMITATION OF INCIDENTAL OR CONSEQUENTIAL DAMAGES,
                                SO THE ABOVE LIMITATION OR EXCLUSION MAY NOT APPLY TO YOU, IN WHICH
                                INSTANCE THE MAXIMUM LIABILITY OF WORLD CULTURES & LANGUAGES
                                INSTITUTE TO YOU IS $100.00 OR THE LOWEST AMOUNT ALLOWABLE UNDER
                                THE APPLICABLE LAWS.

                            </p>
                            <p class="body">
                                3. Indemnification. You agree to defend, indemnify and hold harmless World Cultures &
                                Languages Institute, our officers, directors, shareholders, employees and agents from
                                and against any and all claims, liabilities, damages, losses or expenses, including
                                reasonable attorneys' fees and costs, arising out of or in any way connected with your
                                access to or use of the Site and the Materials.

                            </p>
                            <p class="body">
                                4. Unsolicited Submissions. Except as may be required in connection with your use of
                                World Cultures & Languages Institute Services, World Cultures & Languages Institute
                                does not want you to submit confidential or proprietary information to us through this
                                Site. All comments, feedback, information or material submitted to World Cultures &
                                Languages Institute through or in association with this Site shall be considered
                                non-confidential. By providing such submissions to World Cultures & Languages
                                Institute you hereby grant World Cultures & Languages Institute a license to use,
                                reprint, distribute, modify and create derivative works which will be owned by World
                                Cultures & Languages Institute. You acknowledge that you are responsible for the
                                submissions that you provide, including their legality, reliability, appropriateness,
                                originality, and content.

                            </p>
                            <p class="body">
                                5. Compliance with Intellectual Property Laws.When accessing World Cultures &
                                Languages Institute or using World Cultures & Languages Institute's Services, you
                                agree to obey the law and you agree to respect the intellectual property rights of others.
                                Your use of the Service and the Site is at all times governed by and subject to laws
                                regarding copyright, trademark and other intellectual property ownership. You agree not
                                to upload, download, display, perform, transmit or otherwise distribute any information
                                or content in violation of any third party's copyrights, trademarks or other intellectual
                                property or proprietary rights. You agree to abide by laws regarding copyright ownership
                                and use of intellectual property, and you shall be solely responsible for any violations of
                                any relevant laws and for any infringements of third party rights caused by any content
                                you provide or transmit or that is provided or transmitted using your World Cultures &
                                Languages Institute user account. If you believe that any Content on the Site is
                                infringing on your copyright, you may seek the removal of such Content by providing
                                notice to us in accordance with the Notice and Take Down provisions of the Digital
                                Millennium Copyright Act at World Cultures & Languages Institute as described above
                                in Section 5.1.

                            </p>
                            <p class="body">
                                6. Inappropriate Content. When accessing the Site or using World Cultures &
                                Languages Institute's Services, you agree not to upload, download, display, perform,
                                transmit or otherwise distribute any content that: (a) is libelous, defamatory, obscene,
                                pornographic, abusive or threatening; (b) advocates or encourages conduct that could
                                constitute a criminal offense, give rise to civil liability or otherwise violate any applicable
                                local, state, national or foreign law or regulation; or (c) advertises or otherwise solicits
                                funds or is a solicitation for goods or services. World Cultures & Languages Institute
                                reserves the right to terminate or delete such material from its servers. World Cultures &
                                Languages Institute will cooperate fully with any law enforcement officials or agencies in
                                the investigation of any violation of these Terms of Use or of any applicable laws.

                            </p>
                            <p class="body">
                                7. Children. Minors are not eligible to use the Site and we ask that they do not submit
                                any personal information to us.

                            </p>
                            <p class="body">
                                8. Governing Law; Venue. By using this Site, you expressly agree that your rights and
                                obligations shall be governed by and interpreted in accordance with the laws of the
                                State of Connecticut, excluding its choice of law rules. Any legal action or proceeding
                                relating to your access to or use of the Site or Materials shall be instituted in a state or
                                federal court in the State of Connecticut, County of Fairfield. You and World Cultures &
                                Languages Institute agree exclusively and irrevocably to submit to the jurisdiction of and
                                agree that venue is proper in these courts in any such legal action or proceeding. These
                                Terms of Use expressly exclude and disclaim the terms of the U.N. Convention on
                                Contracts for the International Sale of Goods, which shall not apply to any transaction
                                conducted through or otherwise involving this Site.
                            </p>
                            <p class="body">
                                9. Copyrights. All Site design, text, graphics, the selection and arrangement thereof,
                                Copyright © 2017, World Cultures & Languages Institute, ALL RIGHTS RESERVED.

                            </p>
                            <p class="body">
                                10. Trademarks. World Cultures & Languages Institute, all images and text, and all page
                                headers, custom graphics, and button icons are service marks, trademarks and/or trade
                                dress of World Cultures & Languages Institute. All other trademarks, product names,
                                and company names or logos cited herein are the property of their respective owners.

                            </p>
                            <p class="body">
                                11. Acknowledgment. BY USING World CULTURES & LANGUAGES INSTITUTE'S
                                SERVICES OR ACCESSING THE World CULTURES & LANGUAGES INSTITUTE
                                SITE, YOU ACKNOWLEDGE THAT YOU HAVE READ THESE TERMS OF USE AND
                                AGREE TO BE BOUND BY THEM.

                            </p>
                            <p class="body">
                                12. Contact. If you have any questions about these Terms of Use, the practices of this
                                website, or your dealings with this website, you can contact us at
                                support@wharton.education.

                            </p>
                            <p class="body">
                                Disclaimer: Throughout this website, we link to various outside learning resources. It is
                                purely for you to link to for information as you go through the study session. World
                                Cultures and Languages Institute does not have any ownership of any of these outside
                                websites and cannot give you any permission to do anything at these websites.
                            </p>
                        </section>


                    </div>
                </div>

            </div>
        </div>
    </div>
</template>
<script>
export default {
    mounted(){
        AOS.init();
    }
}
</script>
