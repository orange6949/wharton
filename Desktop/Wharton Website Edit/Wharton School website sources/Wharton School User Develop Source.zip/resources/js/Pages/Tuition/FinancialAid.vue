<template>
    <div>
        <div class="subVisual">
            <h3 class="title">Financial Aid</h3>
            <img src="/img/subVisual04.jpg" alt="">
        </div>

        <div class="subContent area-ccsd">
            <div class="wrap">

                <div class="section type01">
                    <div class="section-title">
                        <img src="/img/ccsd.png" alt="">
                    </div>
                    <div class="section-body">
                        <div class="bodies">
                            <div class="body-wrap">
                                <h3 class="body "  data-aos="fade-up" data-aos-duration="1500">
                                    Wharton School has been participating in the Clark County School District Title I program. Title I
                                    is a federally-funded program that provides supplemental instructional services to eligible
                                    students who are attending public or private schools. The amount of funds available to provide
                                    this service to private school students is determined by the number of low-income students
                                    living in the participating Title I attendance zone. For Title I purposes, low-income is defined as
                                    being eligible for, but not necessarily participating in, the federally-funded free-and-reduced
                                    lunch program.

                                </h3>
                            </div>

                            <div class="body-wrap">
                                <h3 class="body "  data-aos="fade-up" data-aos-duration="1500">

                                    To be eligible to participate in the Title I program, a student does not have to be low-income but
                                    must live in a participating Title I school attendance zone. Students participating in the Title I
                                    program must be identified through multiple criteria assessment as having an educational
                                    attainment that is below the level appropriate for their grade level. Should you choose to have
                                    eligible students participate in this program, further consultation will be necessary to outline
                                    program requirements and to agree upon the design of a viable program.

                                </h3>
                            </div>

                            <div class="body-wrap">
                                <h3 class="body "  data-aos="fade-up" data-aos-duration="1500">
                                    If you would like to check your eligibility for the Title I program, please contact
                                    financialaid@wharton.education.
                                </h3>
                            </div>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</template>
<script>
export default {
    mounted(){
        AOS.init();
    }
}
</script>
