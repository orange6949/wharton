<template>
    <div>
        <div class="subVisual">
            <h3 class="title">Tuition & Fees</h3>
            <img src="/img/subVisual04.jpg" alt="">
        </div>

        <div class="subContent area-tuition">
            <div class="wrap">
                <h3 class="m-title type01" style="text-align:center;" data-aos="fade-up" data-aos-duration="1500">
                    Wharton provides a priceless education at affordable tuition rates.
                    <br/>We never stop working to make Wharton as affordable as possible.
                </h3>

                <div class="m-section type01" data-aos-duration="1500" data-aos="fade-up">
                    <div class="section-title">
                        Costs for 2023-2024
                    </div>

                    <div class="section-body">
                        <div class="m-table-wrap m-scrollbar type01">
                            <table class="m-table type01">
                                <thead>
                                <tr>
                                    <th>Education Program</th>
                                    <th>2023-2024</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>Application Fee</td>
                                    <td>$50</td>
                                </tr>
                                <tr>
                                    <td>Registration Fee</td>
                                    <td>$200</td>
                                </tr>
                                <tr>
                                    <td>Installment Fee</td>
                                    <td>$200</td>
                                </tr>
                                <tr>
                                    <td>Technology Fee</td>
                                    <td>$25 per semester</td>
                                </tr>
                                <tr>
                                    <td>
                                        Tuition for ESL
                                        <p class="m-sub type01">(20 hours live class per week)</p>
                                    </td>
                                    <td>$1,000 per month</td>
                                </tr>
                                <tr>
                                    <td>Upper School
                                        <p class="m-sub type01">(20 hours live class per week)</p>
                                    </td>
                                    <td>$5,000 per semester</td>
                                </tr>
                                <tr>
                                    <td>
                                        Lower School
                                        <p class="m-sub type01">(20 hours live class per week)</p>
                                    </td>
                                    <td>$5,000 per semester</td>
                                </tr>
                                <tr>
                                    <td>AP Course</td>
                                    <td>$2,500 per course</td>
                                </tr>
                                <tr>
                                    <td>AP Course (Self-Pace Learning)</td>
                                    <td>$1,450 per course</td>
                                </tr>
                                <tr>
                                    <td>Dual Degree</td>
                                    <td>$2,500 per course</td>
                                </tr>

                                </tbody>
                            </table>
                        </div>

                        <div class="bodies type01 mt-10">
                            <p class="body" style="word-break: keep-all; text-align: left;">
                                If you are a student out of Nevada states or international students, please contact our
                                admissions team at admissions@wharton.education to ask more details of Out of States
                                tuition rate.
                            </p>
                        </div>

                    </div>

                </div>

                <!--                <div class="m-table-wrap m-scrollbar type01" data-aos="fade-up" data-aos-duration="1500">
                                    <table class="m-table type01">
                                        <thead>
                                        <tr>
                                            <th colspan="2" class="bg-primary" style="color:#fff;">In-state Tuition</th>
                                        </tr>
                                        <tr>
                                            <th>Education Program</th>
                                            <th>2022 - 2023</th>
                                        </tr>
                                        </thead>
                                        <tbody>

                                        <tr>
                                            <td>
                                                Tuition for ESL
                                            </td>
                                            <td>
                                                $600 per month

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                Upper School
                                            </td>
                                            <td>
                                                $500 per course

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                Summer School
                                            </td>
                                            <td>
                                                $500 per course

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                AP Course
                                            </td>
                                            <td>
                                                $1,050 per course

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                Upper School <span class="accent">(Self-Paced Learning)</span>
                                            </td>
                                            <td>
                                                $1,440 per course

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                AP Course <span class="accent">(Self-Paced Learning)</span>
                                            </td>
                                            <td>
                                                $1,850 per course

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                Application Fee
                                            </td>
                                            <td>
                                                $50

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                Registration Fee
                                            </td>
                                            <td>
                                                $200

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                Technology Fee
                                            </td>
                                            <td>
                                                $20 per semester
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>

                                <div class="m-table-wrap m-scrollbar type01 mt-40" data-aos="fade-up" data-aos-duration="1500">
                                    <table class="m-table type01">
                                        <thead>
                                        <tr>
                                            <th colspan="2" class="bg-primary" style="color:#fff;">Out-of-state Tuition</th>
                                        </tr>
                                        <tr>
                                            <th>Education Program</th>
                                            <th>2022 - 2023</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>
                                                Tuition for ESL
                                            </td>
                                            <td>
                                                $780 per month

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                Upper School
                                            </td>
                                            <td>
                                                $650 per course

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                Summer School
                                            </td>
                                            <td>
                                                $650 per course

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                AP Course
                                            </td>
                                            <td>
                                                $1,050 per course

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                Dual Degree
                                            </td>
                                            <td>
                                                $990 per course

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                Upper School <span class="accent">(Self-Paced Learning)</span>
                                            </td>
                                            <td>
                                                $1,880 per course

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                AP Course <span class="accent">(Self-Paced Learning)</span>
                                            </td>
                                            <td>
                                                $1,980 per course

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                Application Fee
                                            </td>
                                            <td>
                                                $50

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                Registration Fee
                                            </td>
                                            <td>
                                                $200

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                Technology Fee
                                            </td>
                                            <td>
                                                $20 per semester

                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>

                                <p class="m-before-star mt-20" data-aos="fade-up" data-aos-duration="1500">
                                    <span class="primary bold">Quarter Semester:</span> Wharton’s tuition fee is based on a quarter semester schedule. Students will
                                    take up to 13 courses per year and students may graduate within 2 years if the students take
                                    summer courses and complete 24 required units.
                                </p>

                                <p class="m-before-star mt-10" data-aos="fade-up" data-aos-duration="1500">
                                    <span class="primary bold">Self-Paced Learning:</span> Self-paced learning is <span class="bold">a learning style in which individuals advance through
                                    an educational program on their own.</span> You may take the same classes as others, but you'll progress
                                    through the course and complete assignments at your own pace.
                                </p>

                                <p class="m-before-doublestar mt-10" data-aos="fade-up" data-aos-duration="1500">
                                    <span class="primary bold">Online ESL Course:</span> <span class="bold">International students,</span> both at the middle school and high school levels, are
                                    <span class="bold">exempt from the mandatory Wharton Admissions TOEFL submission requirement</span> if they fully
                                    complete Wharton's ESL course.
                                </p>

                                <div class="m-section type01">
                                    <div class="section-title" data-aos="fade-up" data-aos-duration="1500" style="font-size:16px;">
                                        *Upper School & Summer
                                        <br/>School Weekly Event
                                    </div>
                                    <div class="m-section-body">
                                        <p class="m-before-square" data-aos="fade-up" data-aos-duration="1500">
                                            Hours Live Class

                                        </p>
                                        <p class="m-before-square" data-aos="fade-up" data-aos-duration="1500">
                                            6 Hours Email Conversation & Discussion Forum
                                        </p>
                                        <p class="m-before-square" data-aos="fade-up" data-aos-duration="1500">
                                            1 Hour High School Counselor Meeting

                                        </p>
                                    </div>
                                </div>-->
            </div>
        </div>
    </div>
</template>
<script>
export default {
    mounted() {
        AOS.init();
    }
}
</script>
