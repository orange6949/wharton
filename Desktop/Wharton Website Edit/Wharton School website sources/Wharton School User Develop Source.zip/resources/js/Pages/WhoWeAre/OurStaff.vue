<template>
    <div>
        <div class="subVisual">
            <h3 class="title">Our Staff</h3>
            <img src="/img/subVisual01.jpg" alt="">
        </div>

        <div class="subContent area-ourStaff">
            <div class="wrap">
                <div class="m-section type01" data-aos="fade-up" data-aos-duration="1500">
                    <div class="section-title">Administration</div>
                    <div class="section-body">
                        <div class="m-boxes type01">
<!--                            <div class="box-wrap">
                                <div class="box">
                                    <div class="m-ratioBox-wrap">
                                        <div class="m-ratioBoc">
                                            <img src="/img/nadia.png" alt="">
                                        </div>
                                    </div>

                                    <div class="content">
                                        <h3 class="title">Nadia Vlad</h3>
                                        <p class="body">
                                            President
                                            <br/>Chairman, Board of Directors
                                        </p>
                                    </div>
                                </div>
                            </div>-->

                            <div class="box-wrap">
                                <div class="box">
                                    <div class="m-ratioBox-wrap">
                                        <div class="m-ratioBoc">
                                            <img src="/img/person01.png" alt="">
                                        </div>
                                    </div>

                                    <div class="content">
                                        <h3 class="title">Dr. Edward Shih, Ph.D</h3>
                                        <p class="body">Head of School</p>
                                    </div>
                                </div>
                            </div>

<!--                            <div class="box-wrap">
                                <div class="box">
                                    <div class="m-ratioBox-wrap">
                                        <div class="m-ratioBoc">
                                            <img src="/img/daniela.png" alt="">
                                        </div>
                                    </div>

                                    <div class="content">
                                        <h3 class="title">Daniela Sim</h3>
                                        <p class="body">
                                            Director of Admissions
                                            <br/>Treasurer, Board of Directors
                                        </p>
                                    </div>
                                </div>
                            </div>-->

                            <div class="box-wrap">
                                <div class="box">
                                    <div class="m-ratioBox-wrap">
                                        <div class="m-ratioBoc">
                                            <img src="/img/david.png?v=1" alt="">
                                        </div>
                                    </div>

                                    <div class="content">
                                        <h3 class="title">David Gerry</h3>
                                        <p class="body">College Counselor</p>
                                    </div>
                                </div>
                            </div>

                            <div class="box-wrap">
                                <div class="box">
                                    <div class="m-ratioBox-wrap">
                                        <div class="m-ratioBoc">
                                            <img src="/img/beatrice.png" alt="">
                                        </div>
                                    </div>

                                    <div class="content">
                                        <h3 class="title">Beatrice Rolea</h3>
                                        <p class="body">Middle School Counselor</p>
                                    </div>
                                </div>
                            </div>

                            <div class="box-wrap">
                                <div class="box">
                                    <div class="m-ratioBox-wrap">
                                        <div class="m-ratioBoc">
                                            <img src="/img/person03.png" alt="">
                                        </div>
                                    </div>

                                    <div class="content">
                                        <h3 class="title">Ivan Lam, JD MBA</h3>
                                        <p class="body">Community Outreach Counselor</p>
                                    </div>
                                </div>
                            </div>

<!--                            <div class="box-wrap">
                                <div class="box">
                                    <div class="m-ratioBox-wrap">
                                        <div class="m-ratioBoc">
                                            <img src="/img/ruvim.png" alt="">
                                        </div>
                                    </div>

                                    <div class="content">
                                        <h3 class="title">Ruvim Grijuncu</h3>
                                        <p class="body">IT Lead</p>
                                    </div>
                                </div>
                            </div>-->

                            <div class="box-wrap">
                                <div class="box">
                                    <div class="m-ratioBox-wrap">
                                        <div class="m-ratioBoc">
                                            <img src="/img/sunghoon.png?v=2" alt="">
                                        </div>
                                    </div>

                                    <div class="content">
                                        <h3 class="title">Sunghoon Sim, MBA</h3>
                                        <p class="body">Director of International Affairs</p>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="m-section type01" data-aos="fade-up" data-aos-duration="1500">
                    <div class="section-title">Our Faculty</div>
                    <div class="section-body">
                        <div class="m-boxes type01">

                            <div class="box-wrap">
                                <div class="box">
                                    <div class="m-ratioBox-wrap">
                                        <div class="m-ratioBoc">
                                            <img src="/img/person06.png" alt="">
                                        </div>
                                    </div>

                                    <div class="content">
                                        <h3 class="title">Rebekah Sarmiento</h3>
                                        <p class="body">English, Psychology, US History</p>
                                    </div>
                                </div>
                            </div>

                            <div class="box-wrap">
                                <div class="box">
                                    <div class="m-ratioBox-wrap">
                                        <div class="m-ratioBoc">
                                            <img src="/img/person07.png" alt="">
                                        </div>
                                    </div>

                                    <div class="content">
                                        <h3 class="title">Caitlin Ullock</h3>
                                        <p class="body">Biology</p>
                                    </div>
                                </div>
                            </div>

                            <div class="box-wrap">
                                <div class="box">
                                    <div class="m-ratioBox-wrap">
                                        <div class="m-ratioBoc">
                                            <img src="/img/person08.png" alt="">
                                        </div>
                                    </div>

                                    <div class="content">
                                        <h3 class="title">James Waddell</h3>
                                        <p class="body">English & Creative Writing</p>
                                    </div>
                                </div>
                            </div>

                            <div class="box-wrap">
                                <div class="box">
                                    <div class="m-ratioBox-wrap">
                                        <div class="m-ratioBoc">
                                            <img src="/img/person09.png" alt="">
                                        </div>
                                    </div>

                                    <div class="content">
                                        <h3 class="title">Stacy Kianna Ingrisano</h3>
                                        <p class="body">Psychology</p>
                                    </div>
                                </div>
                            </div>

                            <div class="box-wrap">
                                <div class="box">
                                    <div class="m-ratioBox-wrap">
                                        <div class="m-ratioBoc">
                                            <img src="/img/person10.png" alt="">
                                        </div>
                                    </div>

                                    <div class="content">
                                        <h3 class="title">Walter Gregory Kleponis</h3>
                                        <p class="body">Politics and Government</p>
                                    </div>
                                </div>
                            </div>

                            <div class="box-wrap">
                                <div class="box">
                                    <div class="m-ratioBox-wrap">
                                        <div class="m-ratioBoc">
                                            <img src="/img/person11.png" alt="">
                                        </div>
                                    </div>

                                    <div class="content">
                                        <h3 class="title">Kristi Rae</h3>
                                        <p class="body">American History</p>
                                    </div>
                                </div>
                            </div>

                            <div class="box-wrap">
                                <div class="box">
                                    <div class="m-ratioBox-wrap">
                                        <div class="m-ratioBoc">
                                            <img src="/img/person12.png" alt="">
                                        </div>
                                    </div>

                                    <div class="content">
                                        <h3 class="title">Crystal Dodd</h3>
                                        <p class="body">English & Elective Courses</p>
                                    </div>
                                </div>
                            </div>

                            <div class="box-wrap">
                                <div class="box">
                                    <div class="m-ratioBox-wrap">
                                        <div class="m-ratioBoc">
                                            <img src="/img/person13.png" alt="">
                                        </div>
                                    </div>

                                    <div class="content">
                                        <h3 class="title">John Mark Seymour</h3>
                                        <p class="body">AP World History & Economics</p>
                                    </div>
                                </div>
                            </div>

                            <div class="box-wrap">
                                <div class="box">
                                    <div class="m-ratioBox-wrap">
                                        <div class="m-ratioBoc">
                                            <img src="/img/person14.png" alt="">
                                        </div>
                                    </div>

                                    <div class="content">
                                        <h3 class="title">Jennifer Huber</h3>
                                        <p class="body">Social Studies</p>
                                    </div>
                                </div>
                            </div>

                            <div class="box-wrap">
                                <div class="box">
                                    <div class="m-ratioBox-wrap">
                                        <div class="m-ratioBoc">
                                            <img src="/img/person15.png" alt="">
                                        </div>
                                    </div>

                                    <div class="content">
                                        <h3 class="title">Kimberly Williams</h3>
                                        <p class="body">Science</p>
                                    </div>
                                </div>
                            </div>

                            <div class="box-wrap">
                                <div class="box">
                                    <div class="m-ratioBox-wrap">
                                        <div class="m-ratioBoc">
                                            <img src="/img/xiao.png" alt="">
                                        </div>
                                    </div>

                                    <div class="content">
                                        <h3 class="title">Xiaowei Hunt</h3>
                                        <p class="body">AP Chinese Reader Assigned by College Board</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    mounted(){
        AOS.init();
    }
}
</script>
