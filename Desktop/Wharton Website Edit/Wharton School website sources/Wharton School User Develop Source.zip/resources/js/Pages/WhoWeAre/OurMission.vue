<template>
    <div>
        <div class="subVisual">
            <h3 class="title">Our Mission & Vision</h3>
            <img src="/img/subVisual01.jpg" alt="">
        </div>

        <div class="subContent area-ourMission">
            <div class="wrap">
                <img src="/img/logo-symbol.png" alt="" class="symbol" data-aos="fade-up" data-aos-duration="1500">

                <h3 class="m-title type01 mt-40" data-aos="fade-up" data-aos-duration="1500">
                    To bring glory to <span class="accent">God</span> by supporting our students and their families,
                    <br/>our faculty members, and our partners. To provide hope and positively impact
                    <br/>everyone who comes in contact with <span class="bold">Wharton</span>.
                </h3>

                <p class="body mt-20" data-aos="fade-up" data-aos-duration="1500">
                    Wharton offers Advanced Placement courses recognized by the College Board as an AP Online Provider (Code: 598) and maintains all AP courses by passing AP Audit each academic year. We are also one of the Distance Education Program course providers, approved by the Department of Education, Nevada. With a global vision and an aggressive entrepreneurial focus in developing joint educational programs. Our mission is to provide the best possible online learning experience and to support people's lifelong learning with the goal to create a versatile life by acquiring useful knowledge, practical skills, and field studies worldwide.
                </p>

                <div class="boxes">
                    <div class="box-wrap" data-aos="fade-up" data-aos-duration="1500">
                        <div class="box">
                            <div class="m-ratioBox-wrap">
                                <div class="m-ratioBox">
                                    <img src="/img/mission01.jpg" alt="">
                                </div>
                            </div>

                            <h3 class="title">AP Online Provider</h3>
                        </div>
                    </div>
                    <div class="box-wrap" data-aos="fade-up" data-aos-duration="1500">
                        <div class="box">
                            <div class="m-ratioBox-wrap">
                                <div class="m-ratioBox">
                                    <img src="/img/mission02.jpg" alt="">
                                </div>
                            </div>

                            <h3 class="title">
                                Distance Education
                                <br/>Program course providers
                            </h3>
                        </div>
                    </div>
                    <div class="box-wrap" data-aos="fade-up" data-aos-duration="1500">
                        <div class="box">
                            <div class="m-ratioBox-wrap">
                                <div class="m-ratioBox">
                                    <img src="/img/mission03.jpg" alt="">
                                </div>
                            </div>

                            <h3 class="title">
                                Best possible online
                                <br/>learning experience
                            </h3>
                        </div>
                    </div>
                    <div class="box-wrap" data-aos="fade-up" data-aos-duration="1500">
                        <div class="box">
                            <div class="m-ratioBox-wrap">
                                <div class="m-ratioBox">
                                    <img src="/img/mission04.jpg" alt="">
                                </div>
                            </div>

                            <h3 class="title">
                                Create a versatile life
                            </h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    mounted(){
        AOS.init();
    }
}
</script>
