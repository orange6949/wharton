<template>
    <div>
        <div class="subVisual">
            <h3 class="title">About Us</h3>
            <img src="/img/subVisual01.jpg" alt="">
        </div>

        <div class="subContent area-aboutUs">
            <div class="wrap">

                <div class="fragments">
                    <div class="fragment-wrap" data-aos="fade-right" data-aos-duration="1500" data-aos-delay="300">
                        <div class="fragment">
                            <div class="box-img">
                                <img src="/img/logo-symbol.png" alt="" data-aos="fade-up" data-aos-duration="1500" class="thumbnail">
                            </div>
                        </div>
                    </div>

                    <div class="fragment-wrap" data-aos="fade-left" data-aos-duration="1500" data-aos-delay="300">
                        <div class="fragment">
                            <div class="content">
                                <p class="greet">
                                    Dear Students
                                </p>

                                <p class="body">
                                    Welcome to Wharton School, a school committed to offering students a rigorous, college preparatory high school program (grades 9-12) in an interactive, 21st century online format. (E)
                                </p>
                                <p class="body">
                                    Our online classroom offers a high degree of connectivity between you, your fellow students, and your instructor. All courses are considered college preparatory and prepare students
                                    both academically and with relevant skill sets to better prepare you for continued post-secondary education or the workforce. With bilingual and dual-language education in mission,
                                    Wharton provides you with the ability to learn with other students around the globe and across a variety of diverse, multicultural, and regional perspectives.
                                </p>

                                <p class="body">
                                    Welcome to Wharton School! - We promise that you will have a positive educational experience.
                                </p>

<!--                                <p class="sign">President Nadia Vlad</p>-->
                            </div>
                        </div>
                    </div>
                </div>
                <h3 class="m-title type01" data-aos="fade-up" data-aos-duration="1500">
                    We help students achieve their academic goals by offering
                </h3>

                <div class="bodies" data-aos="fade-up" data-aos-duration="1500">
                    <p class="body m-before-square">
                        Rigorous AP courses
                    </p>

                    <p class="body m-before-square">
                        Accredited high school & college courses
                    </p>

                    <p class="body m-before-square">
                        Preparation courses
                    </p>

                    <p class="body m-before-square">
                        HSK Chinese proficiency test and GED exam preparation courses
                    </p>

                    <p class="body m-before-square">
                        Industrial certificate programs
                    </p>

                    <p class="body m-before-square">
                        Online community with eCommerce features & real world applications
                    </p>
                </div>

                <div class="m-section type01 mt-40" data-aos="fade-up" data-aos-duration="1500">
                    <div class="section-title">
                        About WCLI
                        <br/>Who We Are
                    </div>

                    <div class="section-body">
                        <div class="bodies">
                            <p class="body">
                                At World Cultures and Languages Institute (WCLI), we’re dedicated to providing an accredited K-12 online education for students everywhere. We’re proud to be able to offer such a broad range of online learning programs including high school, online AP courses, Dual Enrollment courses and more.
                            </p>
                        </div>
                    </div>
                </div>

                <div class="m-section type01" data-aos="fade-up" data-aos-duration="1500">
                    <div class="section-title">
                        Our Mission
                    </div>

                    <div class="section-body">
                        <div class="bodies">
                            <p class="body">
                                Our mission is to provide the best possible online learning experience and to support people's lifelong learning with the goal to create a versatile life by acquiring useful knowledge, practical skills, and field studies worldwide.
                            </p>
                        </div>
                    </div>
                </div>

                <div class="m-section type01" data-aos="fade-up" data-aos-duration="1500">
                    <div class="section-title">
                        Enriching Lives
                        <br/>& Creating Futures
                    </div>

                    <div class="section-body">
                        <div class="bodies">
                            <p class="body">
                                Wharton students can attend various free classes; each of which focuses on specific topics and practical skills. With no scheduled class times, students have the ability to learn whenever it is most convenient for them. What’s more? They can also make friends and share relevant information with other students in our online community.
                            </p>
                            <p class="body mt-20">
                                At the end of each term, we provide students with the opportunity to attend hands-on workshops that are specially designed to help them create a professional product or service for their use or for sale on our online store. This type of workshop also allows students to take retailing industry-related field trips to enhance their learning.
                            </p>
                        </div>
                    </div>
                </div>

                <div class="m-section type01" data-aos="fade-up" data-aos-duration="1500">
                    <div class="section-title">
                        Accreditation
                    </div>

                    <div class="section-body">
                        <div class="bodies">
                            <p class="body">
                                <a href="/file/license.pdf" download class="m-btn type02">
                                    Download School License
                                    <img src="/img/download-primary.png" alt="">
                                </a>
                            </p>

                            <p class="body mt-10">
                                <a href="/file/AgentPermit.pdf" download class="m-btn type02">
                                    Agent Permit
                                    <img src="/img/download-primary.png" alt="">
                                </a>
                            </p>

                            <p class="body mt-10">
                                Wharton School is accredited by Cognia and licensed by the Nevada State Board of Education with online courses approved by the Nevada Department of Education. Our AP (Advanced Placement) courses are audited and approved by the College Board.
                            </p>
                        </div>
                    </div>
                </div>

                <div class="m-section type01" data-aos="fade-up" data-aos-duration="1500">
                    <div class="section-title">
                        Our Partners
                    </div>

                    <div class="section-body">
                        <div class="boxes">
                            <div class="box-wrap">
                                <div class="box">
                                    <img src="/img/partner01.png" alt="">
                                </div>
                            </div>

                            <div class="box-wrap">
                                <div class="box">
                                    <img src="/img/partner02.png" alt="">
                                </div>
                            </div>

                            <div class="box-wrap">
                                <div class="box">
                                    <img src="/img/partner03.png" alt="">
                                </div>
                            </div>

                            <div class="box-wrap">
                                <div class="box">
                                    <img src="/img/partner04.png" alt="">
                                </div>
                            </div>

                            <div class="box-wrap">
                                <div class="box">
                                    <img src="/img/partner05.png" alt="">
                                </div>
                            </div>

                            <div class="box-wrap">
                                <div class="box">
                                    <img src="/img/partner06.png" alt="">
                                </div>
                            </div>

                            <div class="box-wrap">
                                <div class="box">
                                    <img src="/img/partner07.png" alt="">
                                </div>
                            </div>

                            <div class="box-wrap">
                                <div class="box">
                                    <img src="/img/partner08.png" alt="">
                                </div>
                            </div>

                            <div class="box-wrap">
                                <div class="box">
                                    <img src="/img/partner09.png" alt="">
                                </div>
                            </div>

                            <div class="box-wrap">
                                <div class="box">
                                    <img src="/img/partner10.png" alt="">
                                </div>
                            </div>

                            <div class="box-wrap">
                                <div class="box">
                                    <img src="/img/partner11.png" alt="">
                                </div>
                            </div>

                            <div class="box-wrap">
                                <div class="box">
                                    <img src="/img/partner12.png" alt="">
                                </div>
                            </div>

                            <!--
                            <div class="box-wrap">
                                <div class="box">
                                    <img src="/img/partner13.png" alt="">
                                </div>
                            </div>
                            -->

                            <div class="box-wrap">
                                <div class="box">
                                    <img src="/img/partner14.png" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    mounted(){
        AOS.init();
    }
}
</script>
