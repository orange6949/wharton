<template>
    <div>
        <div class="subVisual">
            <h3 class="title">Dual Enrollment</h3>
            <img src="/img/subVisual03.jpg" alt="">
        </div>

        <div class="subContent area-dualEnrollment">
            <div class="wrap">
                <div class="boxes">
                    <div class="box-wrap" data-aos-duration="1500" data-aos="fade-right">
                        <div class="box">
                            <div class="box-img">
                                <img src="/img/enrollment01.png" alt="">
                            </div>

                            <h3 class="title">California State University 0+4 Program</h3>

                            <div class="body">
                                <p class="primary" style="font-weight:500;">PREPARE FOR YOUR MASTER’S DEGREE AND CAREER SUCCESS IN THE U.S.</p>
                                Wharton Global Pathways helps you to strengthen your academics, transition to American culture and an American classroom, and improve your English skills. Taught by PhD level instructors, the program is designed to offer dedicated support in a welcoming environment.
                            </div>
                            <div class="body">
                                After successful completion of Global Pathways at Wharton High School and its progression requirements, you can transfer to your bachelor's degree in the area of your interest in California State University San Bernardino Campus without any required tests.
                            </div>
                            <div class="body">
                                California State University—San Bernardino is a public institution that was founded in 1962. It has a total undergraduate enrollment of 18,114, its setting is suburban, and the campus size is 430 acres. It utilizes a quarter-based academic calendar. California State University—San Bernardino's ranking in the 2021 edition of Best Colleges is Regional Universities West, #40. Its in-state tuition.
                            </div>
                        </div>
                    </div>

                    <div class="box-wrap" data-aos-duration="1500" data-aos="fade-left">
                        <div class="box">
                            <div class="box-img">
                                <img src="/img/enrollment02.png" alt="">
                            </div>

                            <h3 class="title">UC Riverside 2+2 Program</h3>

                            <div class="body">
                                <p class="primary" style="font-weight:500;">We Are More Than a School...We're a Bridge to Your Future!</p>
                                We are in the course articulation process of Concurrent Enrollment (Dual Credit) with Riverside City College (RCC). Successful graduate students can then transfer to the University of California, Riverside (UCR), via the 2+2 joint program between RCC and UCR.
                            </div>
                            <div class="body">
                                Welcome to participate in this concurrent enrollment program between RCC and Wharton High School and put your college in high school.
                            </div>
                            <div class="body">
                                We have programs and activities that meet your goals and interests. At RCC we offer degree and certificate programs. We are an affordable starting point for transfer to the college/university of your choice. We will lead you to your dream career. Be empowered. Be transformed.
                            </div>
                            <div class="body">
                                The University of California, Riverside is one of 10 campuses in the #1 public university system in the U.S. UCR is known as the most diverse and internationally-friendly campus in the UC system, and has nearly 80,000 alumni, many of whom have won prestigious awards such as the Guggenheim Fellowship, Nobel Prize, Pulitzer Prize, and others.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    data(){
        return {

        }
    },

    methods: {

    },

    mounted(){
        AOS.init();
    }
}
</script>
