<template>
    <div>
        <div class="subVisual">
            <h3 class="title">Q&A</h3>
            <img src="/img/subVisual03.jpg" alt="">
        </div>

        <div class="subContent area-qna">
            <div class="wrap">
                <div class="m-section type01" data-aos="fade-up" data-aos-duration="1500">
                    <div class="section-title">Q</div>
                    <div class="section-body">
                        <h3 class="m-title type01">What are the enrollment requirements?</h3>

                        <div class="bodies type01">
                            <p class="body">
                                1. All students seeking to enroll in our online high school programs must be able to demonstrate a working knowledge of the English language.
                            </p>
                            <p class="body">
                                2. Students enrolling in our high school program must be able to provide proof of completing the eighth grade.
                            </p>
                            <p class="body">
                                3. Students entering Wharton High School need to show a school transcript, or standardized test scores indicating at or above 8th grade level
                                performance in all subject areas.
                            </p>
                            <p class="body">
                                4. Students entering Wharton High School must be at least 14 years of age.
                            </p>
                        </div>
                    </div>
                </div>

                <div class="m-section type01" data-aos="fade-up" data-aos-duration="1500">
                    <div class="section-title">Q</div>
                    <div class="section-body">
                        <h3 class="m-title type01">Can I enroll if I live outside of the United States?</h3>

                        <div class="bodies type01">
                            <p class="body">
                                Yes, we welcome students from different countries. If you are not in the U.S. and interested in enrolling in our school. Please call the counselor
                                at 1-702-9903555, or send an email to us at support@wharton.education or fill out the request form
                            </p>
                        </div>
                    </div>
                </div>

                <div class="m-section type01" data-aos="fade-up" data-aos-duration="1500">
                    <div class="section-title">Q</div>
                    <div class="section-body">
                        <h3 class="m-title type01">How do I enroll?</h3>

                        <div class="bodies type01">
                            <p class="body">We enroll students in the courses through a membership system. Students will register for the courses by themselves.</p>
                            <!-- 수정필요 #3 -->
                            <a href="#" class="body link mt-10">Check our enrollment plans here >></a>
                        </div>

                        <h3 class="m-title type01 mt-40">Here are the steps for class sign-up.</h3>
                        <div class="bodies type01">
                            <p class="body">
                                1. Create an account on our website.

                            </p>
                            <p class="body">
                                2. Send the required materials at support@wharton.education

                            </p>
                            <p class="body">
                                3. Choose one of the enrollment plans and sign up for the courses. (If you want to enroll in an individual course, please send your request at
                                support@wharton.education)

                            </p>
                            <p class="body">
                                4. Pay the tuition with PayPal.

                            </p>
                            <p class="body">
                                5. Access the courses by clicking the menu "My course" under the menu item "Student Registration". (Log in to see this menu)
                            </p>
                        </div>
                    </div>
                </div>

                <div class="m-section type01" data-aos="fade-up" data-aos-duration="1500">
                    <div class="section-title">Q</div>
                    <div class="section-body">
                        <h3 class="m-title type01">When can I start to learn?</h3>

                        <div class="bodies type01">
                            <p class="body">After your enrollment and payment, you can access your courses and start to learn</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    data(){
        return {

        }
    },

    methods: {

    },

    mounted(){
        AOS.init();
    }
}
</script>
