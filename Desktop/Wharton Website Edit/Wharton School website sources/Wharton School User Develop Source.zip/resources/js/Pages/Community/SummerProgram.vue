<template>
    <div>
        <div class="subVisual">
            <h3 class="title">2022 Summer 10-Weeks Accelerated AP Program</h3>
            <img src="/img/subVisual07.jpg" alt="">
        </div>

        <div class="subContent area-summerProgram">
            <div class="wrap">
                <div class="box-top">
                    <img src="/img/logo-symbol.png" alt="" data-aos="fade-up" data-aos-duration="1500">

                    <p class="body" data-aos="fade-up" data-aos-duration="1500">
                        Wharton School will be providing AP courses via online from July 11th to September 16th
                        <br/>(10-weeks) 2022. Wharton’s AP course subjects will be AP Biology, AP Calculus BC, and AP
                        <br/>Chinese. A live class will be held every Tuesday for an hour (based on EST / Live Class
                        <br/>Schedule - TBA). Students are required to take Online Learning Readiness (OLR) for a week.
                        <br/>This online learning readiness orientation module aims to help students explore the academic
                        <br/>skills needed to succeed at the college level and in the online learning environment.
                    </p>
                </div>

                <div class="box-prices-wrap" data-aos="fade-up" data-aos-duration="1500">
                    <div class="box-prices">
                        <div class="box-price" data-aos="fade-up" data-aos-duration="1500">
                            <h3 class="title">Summer AP Course Tuition</h3>
                            <p class="body">$1,150 / Course</p>
                        </div>

                        <div class="box-price" data-aos="fade-up" data-aos-duration="1500">
                            <h3 class="title">Early Registration Tuition <span class="primary bold">(25% Off)</span></h3>
                            <p class="body bg-primary">$850 / Course</p>
                        </div>
                    </div>

                    <p class="comment" data-aos="fade-up" data-aos-duration="1500">
                        Register early for AP classes by <span class="bold primary">June 10th 2022</span>,
                        to receive a <span class="primary bold">discount of up to 25% on your tuition.</span>
                    </p>
                </div>

                <div class="m-section type01 mt-40" data-aos="fade-up" data-aos-duration="1500">
                    <div class="section-title">
                        2022 AP Course
                        <br/>Subjects I
                    </div>

                    <div class="section-body">
                        <div class="bodies">
                            <p class="body m-before-square">
                                <span class="primary bold">OLR / 1 Week Schedule :</span> July 19th - July 25th (OLR / 1 Week)
                            </p>
                            <p class="body m-before-square">
                                <span class="primary bold">10 Weeks Schedule :</span> July 26th - October 9th (10 Weeks)
                            </p>
                            <p class="body m-before-square">
                                AP Biology
                            </p>
                            <p class="body m-before-square">
                                AP Calculus BC
                            </p>
                            <p class="body m-before-square">
                                AP Chinese
                            </p>
                        </div>
                    </div>
                </div>

                <div class="m-section type01" data-aos="fade-up" data-aos-duration="1500">
                    <div class="section-title">
                        2022 AP Course
                        <br/>Subjects II
                    </div>

                    <div class="section-body">
                        <div class="bodies">
                            <p class="body m-before-square">
                                <span class="bold primary">OLR / 1 Week Schedule :</span> September 19th - September 25th (OLR / 1 Week)
                            </p>
                            <p class="body m-before-square">
                                <span class="bold primary">10 Weeks Schedule :</span> September 26th - December 9th (10 Weeks)
                            </p>
                            <p class="body m-before-square">
                                AP Chinese
                            </p>
                            <p class="body m-before-square">
                                AP Statistics
                            </p>
                        </div>
                    </div>
                </div>

                <div class="m-section type01" data-aos="fade-up" data-aos-duration="1500">
                    <div class="section-title">
                        Why Wharton?
                    </div>

                    <div class="section-body">
                        <div class="bodies">
                            <p class="body m-before-square"><span class="bold primary">Fast</span> - 10-Weeks Accelerated Program!</p>
                            <p class="body m-before-square"><span class="bold primary">Affordable</span> - Tuition per course as low as $850!</p>
                            <p class="body m-before-square"><span class="bold primary">Easy</span> - Academic Counselor to help you raise your GPA.</p>
                            <p class="body mt-20">
                                Wharton school is licensed by the Nevada State Board of Education with the online courses approved by the Nevada
                                Department of Education. Our AP (Advanced Placement) courses are audited and approved by the College Board.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import {Link} from '@inertiajs/inertia-vue';

export default {
    components: {Link},
    data() {
        return {

        }
    },

    mounted() {
        AOS.init();
    },

    methods: {

    }
}
</script>
