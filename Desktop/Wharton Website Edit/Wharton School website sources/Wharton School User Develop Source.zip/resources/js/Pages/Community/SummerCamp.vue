<template>
    <div>
        <div class="subVisual">
            <h3 class="title">SUMMER CAMP</h3>
            <img src="/img/subVisual07.jpg" alt="">
        </div>

        <div class="subContent area-summerCamp">
            <div class="wrap">
                <div class="box-title">
                    <p class="body" data-aos="fade-up" data-aos-duration="1500">2022.07.18 - 2022.08.13</p>
                    <h3 class="title" data-aos="fade-up" data-aos-duration="1500">
                        WHARTON SCHOOL <br class="m"/>SUMMER CAMP
                    </h3>
                </div>

                <div class="box-content">
                    <img src="/img/summerCamp01.jpg" alt="" class="thumbnail" data-aos="fade-up" data-aos-duration="1500">

                    <div class="box-comment">
                        <div class="bodies">
                            <p class="body" data-aos="fade-up" data-aos-duration="1500">
                                Wharton prides itself in pioneering programs that have a lasting
                                <br/>impact on student success.
                            </p>
                        </div>
                        <div class="bodies">
                            <h3 class="title" data-aos="fade-up" data-aos-duration="1500">Our Programs</h3>
                            <p class="m-before-hyphen" data-aos="fade-up" data-aos-duration="1500">
                                Intensive ESL & special English programs for high school students
                            </p>
                            <p class="m-before-hyphen" data-aos="fade-up" data-aos-duration="1500">
                                Business & Entrepreneurship special mentoring programs
                            </p>
                            <p class="m-before-hyphen" data-aos="fade-up" data-aos-duration="1500">
                                Weekly motivational lectures
                            </p>
                            <p class="m-before-hyphen" data-aos="fade-up" data-aos-duration="1500">
                                University tours with special mentors
                            </p>
                            <p class="m-before-hyphen" data-aos="fade-up" data-aos-duration="1500">
                                Guest speakers
                            </p>
                        </div>
                        <div class="bodies">
                            <p class="body" data-aos="fade-up" data-aos-duration="1500">
                                The 2022 Wharton School Summer Camp program is jointly organized
                                <br/>with Wharton Education Agency (WEA) Korea, the official Wharton School in Korea.
                            </p>
                        </div>
                        <div class="bodies">
                            <p class="body" data-aos="fade-up" data-aos-duration="1500">
                                Haeundae Berkeley Academy Busan, with its grand opening of Wharton High School Busan Campus
                                <br/>next year, plans to provide high-level English education and various customized activity programs.
                            </p>
                            <p class="body" data-aos="fade-up" data-aos-duration="1500">
                                We warmly invite Korean students to the 2022 Wharton Summer Camp.
                                <br/>We hope to welcome you to the Wharton community.
                            </p>
                            <p class="body" data-aos="fade-up" data-aos-duration="1500">
                                Wharton School Learning Center
                                <br/>Baltimore Campus, Maryland
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import {Link} from '@inertiajs/inertia-vue';

export default {
    components: {Link},
    data() {
        return {

        }
    },

    mounted() {
        AOS.init();
    },

    methods: {

    }
}
</script>
