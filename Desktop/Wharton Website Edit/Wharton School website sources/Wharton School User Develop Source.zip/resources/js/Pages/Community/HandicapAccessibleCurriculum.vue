<template>
    <div>
        <div class="subVisual">
            <h3 class="title">Handicap Accessible Curriculum</h3>
            <img src="/img/subVisual04.jpg" alt="">
        </div>

        <div class="subContent area-emergency">
            <div class="wrap">

                <div class="box-comment">
                    <h3 class="m-title type01">
                        Handicap Accessible Curriculum & Website at Wharton school
                        <br/>to support hearing or visible impairments students.
                    </h3>
                </div>

                <div data-aos-duration="1500" data-aos="fade-up" class="m-section type01 aos-init aos-animate">
                    <div class="section-title">
                        1) change font size and color & text
                        <br/>to speech for visible impairments students
                    </div>
                    <div class="section-body">
                        <div class="bodies type01">
                            <p class="body">
                                At Wharton school, we have used Moove theme in our Moodle learning Management website,
                                so we do provide Accessibility settings feature:
                            </p>
                        </div>
                        <p class="body">
                            <img src="/img/image1.png" alt="">
                        </p>

                        <div class="bodies type01">
                            <div class="body m-before-square">
                                1-1) Accessibility settings
                            </div>

                            <img src="/img/image2.png" alt="">

                            <div class="body m-before-square">
                                1-2) Check Toolbar
                            </div>

                            <img src="/img/image3.png" alt="">

                            <div class="body m-before-square">
                                1-3) Read Aloud: A Text to Speech Voice Reader

                                <div class="bodies type01">
                                    <p class="m-before-hyphen">
                                        Read aloud the current web-page article with one click, using text to speech (TTS).
                                    </p>
                                </div>
                            </div>

                            <img src="/img/image4.png" alt="">
                        </div>
                    </div>
                </div>

                <div data-aos-duration="1500" data-aos="fade-up" class="m-section type01 aos-init aos-animate">
                    <div class="section-title">
                        2) We provide the subtitle (captions)
                        <br/>of videos to support hearing
                        <br/>impairments students.
                    </div>
                    <div class="section-body">
                        <img src="/img/image5.png" alt="">
                    </div>
                </div>

            </div>
        </div>
    </div>
</template>
<script>
export default {
    mounted() {
        AOS.init();
    }
}
</script>
