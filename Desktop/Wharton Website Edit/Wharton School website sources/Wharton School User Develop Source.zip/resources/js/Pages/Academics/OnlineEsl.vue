<template>
    <div>
        <div class="subVisual">
            <h3 class="title">Online ESL</h3>
            <img src="/img/subVisual02.jpg" alt="">
        </div>

        <div class="subContent area-onlineEsl">
            <div class="wrap">
                <div class="m-box-img type01">
                    <div class="box-text">
                        <h3 class="title">Online ESL</h3>
                        <p class="body">
                            Our English programs are structured to accelerate your learning with optimal time in the classroom.
                        </p>
                    </div>
                    <img src="/img/onlineEsl.jpg" alt="">
                </div>

                <div class="box-comment">
                    International students, both at the middle school and high school levels,
                    <br/>are exempt from the mandatory Wharton Admissions TOEFL submission requirement
                    <br/>if they fully complete Wharton's ESL course.
                </div>

                <div data-aos-duration="1500" data-aos="fade-up" class="m-section type01 aos-init aos-animate">
                    <div class="section-title">
                        Advanced ESL
                    </div>
                    <div class="section-body">
                        <p class="body">
                            Although Wharton requires international students to demonstrate their proficiency in English
                            before
                            they can be accepted, the Academy does provide additional instructional services for English
                            as a
                            Second Language learners (ESL). Wharton offers courses in ESL and Advanced ESL for middle
                            and high
                            school students.
                        </p>
                     </div>
                </div>

                <div data-aos-duration="1500" data-aos="fade-up" class="m-section type01 aos-init aos-animate">
                    <div class="section-title">
                        Our English Programs
                    </div>
                    <div class="section-body">
                        <p class="body">
                            Our English programs are structured to accelerate your learning with optimal time in the classroom.
                            These programs help students significantly improve their English skills, and fully prepare them for
                            study in the USA or abroad.
                        </p>
                    </div>
                </div>

                <div data-aos-duration="1500" data-aos="fade-up" class="m-section type01 aos-init aos-animate">
                    <div class="section-title">
                        Q&A
                    </div>
                    <div class="section-body">
                        <p class="body">
                            If you have any questions or want to learn more about Wharton’s ESL programs, please contact
                            esl@wharton.education.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    mounted() {
        AOS.init();
    }
}
</script>
