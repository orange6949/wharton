<template>
    <div>
        <div class="subVisual">
            <h3 class="title">AP Courses</h3>
            <img src="/img/subVisual02.jpg" alt="">
        </div>

        <div class="subContent area-apCourses">
            <div class="wrap">
                <div class="m-section type01 mt-80" data-aos="fade-up" data-aos-duration="1500">
                    <div class="section-title">About AP</div>

                    <div class="section-body">
                        <p class="body">
                            Advanced Placement (AP) is a program in the United States and Canada created by the College Board which offers college-level curricula and examinations to high school students. American colleges and universities may grant placement and course credit to students who obtain high scores on the examinations.
                        </p>
                        <p class="body mt-20">
                            Advanced Placement online classes at Wharton are intended for the very, well-prepared and highly motivated student. Inborn intelligence is not the primary ingredient for success at these classes. Far more important is a higher level of initiative, personal discipline, time management skills, academic maturity and collaborative learning. If grades are essential to you, please make ready for taking an Advanced Placement class here before enrolling in.
                        </p>
                    </div>
                </div>

                <div class="m-section type01" data-aos="fade-up" data-aos-duration="1500">
                    <div class="section-title">AP Courses</div>

                    <div class="section-body">
                        <div class="courses-wrap">
                            <h3 class="title">AP Capstone</h3>

                            <div class="courses">
                                <div class="course-wrap">
                                    <div class="course">AP Research</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP Seminar</div>
                                </div>
                            </div>
                        </div>

                        <div class="courses-wrap">
                            <h3 class="title">Arts</h3>

                            <div class="courses">
                                <div class="course-wrap">
                                    <div class="course">AP Art History</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP Muisc Theroy</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP Studio Art: 2-D Design</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP Studio Art: 3-D Design</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP Studio Art: Drawing</div>
                                </div>
                            </div>
                        </div>

                        <div class="courses-wrap">
                            <h3 class="title">English</h3>

                            <div class="courses">
                                <div class="course-wrap">
                                    <div class="course">AP English Language and Composition</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP English Literature and Composition</div>
                                </div>
                            </div>
                        </div>

                        <div class="courses-wrap">
                            <h3 class="title">History & Social Science</h3>

                            <div class="courses">
                                <div class="course-wrap">
                                    <div class="course">AP Comparative Government and Politics</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP European History</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP Human Geography</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP Macroeconomics</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP Microeconomics</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP Psychology</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP United States Government and Politics</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP United States History</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP Wolrd History</div>
                                </div>
                            </div>
                        </div>

                        <div class="courses-wrap">
                            <h3 class="title">Math & Computer Science</h3>

                            <div class="courses">
                                <div class="course-wrap">
                                    <div class="course">AP Calculus AB</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP Calculus BC</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP Computer Science A</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP Computer Science Principles</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP Statistics</div>
                                </div>
                            </div>
                        </div>

                        <div class="courses-wrap">
                            <h3 class="title">Sciences</h3>

                            <div class="courses">
                                <div class="course-wrap">
                                    <div class="course">AP Biology</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP Chemistry</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP Environmental Science</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP Physics C: Electricity and Magnetism</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP Physics C: Mechanics</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP Physics 1: Algebra-Based</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP Physics 2: Algebra-Based</div>
                                </div>
                            </div>
                        </div>

                        <div class="courses-wrap">
                            <h3 class="title">World Languages & Cultures</h3>

                            <div class="courses">
                                <div class="course-wrap">
                                    <div class="course">AP Chinese Language and Culture</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP French Language and Culture</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP German Language and Culture</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP Italian Language and Culture</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP Japanese Language and Culture</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP Latin</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP Spanish Language and Culture</div>
                                </div>
                                <div class="course-wrap">
                                    <div class="course">AP Spanish Literature and Culture</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="box-top mt-80" data-aos="fade-up" data-aos-duration="1500">
                    <div class="box-img">
                        <img src="/img/apCourses01.jpg" alt="">
                    </div>

                    <form class="m-form type01" @submit.prevent="store">
                        <h3 class="title">Request Course Information</h3>

                        <div class="m-input-wrap type01 mt-20">
                            <h3 class="m-input-title">Grades *</h3>
                            <div class="m-input-checkboxes type01">
                                <div class="m-input-checkbox">
                                    <input type="radio" id="9-12" value="9-12" v-model="form.grades">
                                    <label for="9-12">9-12</label>
                                </div>
                            </div>

                            <p class="m-input-error" v-if="form.errors.grades">{{form.errors.grades}}</p>
                        </div>

                        <div class="m-input-wrap type01">
                            <div class="m-input-text type01">
                                <input type="text" placeholder="First name *" v-model="form.first_name">
                            </div>

                            <p class="m-input-error" v-if="form.errors.first_name">{{form.errors.first_name}}</p>
                        </div>

                        <div class="m-input-wrap type01 ">
                            <div class="m-input-text type01">
                                <input type="text" placeholder="Last name *" v-model="form.last_name">
                            </div>

                            <p class="m-input-error" v-if="form.errors.last_name">{{form.errors.last_name}}</p>
                        </div>

                        <div class="m-input-wrap type01 ">
                            <div class="m-input-text type01">
                                <input type="text" placeholder="Phone *" v-model="form.phone">
                            </div>

                            <p class="m-input-error" v-if="form.errors.phone">{{form.errors.phone}}</p>
                        </div>

                        <div class="m-input-wrap type01 ">
                            <div class="m-input-text type01">
                                <input type="text" placeholder="Email *" v-model="form.email">
                            </div>

                            <p class="m-input-error" v-if="form.errors.email">{{form.errors.email}}</p>
                        </div>

                        <div class="m-input-wrap type01 ">
                            <div class="m-input-text type01">
                                <input type="text" placeholder="State *" v-model="form.state">
                            </div>

                            <p class="m-input-error" v-if="form.errors.state">{{form.errors.state}}</p>
                        </div>

                        <div class="m-input-wrap type01 ">
                            <div class="m-input-text type01">
                                <input type="text" placeholder="Postal Code *" v-model="form.post_code">
                            </div>

                            <p class="m-input-error" v-if="form.errors.post_code">{{form.errors.post_code}}</p>
                        </div>

                        <div class="m-input-textarea type01 ">
                            <div class="m-input-text type01">
                                <textarea name="" id="" placeholder="Comment" v-model="form.comment"></textarea>
                            </div>

                            <p class="m-input-error" v-if="form.errors.comment">{{form.errors.comment}}</p>
                        </div>

                        <button class="m-btn type01 bg-primary mt-20">SUBMIT</button>
                    </form>
                </div>

                <div class="m-section type01 mt-100" data-aos="fade-up" data-aos-duration="1500">
                    <div class="section-title">Courses</div>

                    <div class="section-body">
                        <p class="body">
                            Wharton offers a variety of college preparatory high school core subjects, electives and college credit courses in an interactive
                            learning environment. All Wharton courses are considered rigorous and college preparatory and have been written to Nevada
                            and National standards when appropriate. Each Wharton semester course covers a typical semester's worth of material and is
                            comprised of the following:
                        </p>

                        <div class="bodies mt-20">
                            <p class="body m-before-square">
                                Unit learning outcomes stating the learning objectives students should accomplish in a specific unit. All courses
                                consist of 6-18 units of learning.
                            </p>
                            <p class="body m-before-square">
                                Required reading assignments based on the course textbook or other assigned reading.
                            </p>
                            <p class="body m-before-square">
                                Unit lectures that include insight and analysis of the unit's topics.
                            </p>
                            <p class="body m-before-square">
                                Unit discussion boards where students and instructors communicate ideas and thoughts in a collaborative environment.
                            </p>
                            <p class="body m-before-square">
                                Unit-based assessments including a midterm and final examination to further assess each student's academic acquisition.
                            </p>
                            <p class="body m-before-square">
                                Assignments for students to complete and submit to ensure mastery of learning objectives.
                            </p>
                            <p class="body m-before-square">
                                Course resources that contain readings and documents to assist students in accomplishing unit objectives.
                            </p>
                        </div>

                        <!-- 수정필요 #1 -->
                        <a href="/file/course_catalog.pdf" class="m-btn type02 mt-20">
                            Download Course Catalog
                            <img src="/img/download-primary.png" alt="">
                        </a>
                    </div>
                </div>

                <div class="m-section type01" data-aos="fade-up" data-aos-duration="1500">
                    <div class="section-title"></div>
                    <div class="section-body">
                        <h3 class="m-title type01">Course Offerings</h3>
                        <div class="bodies">
                            <p class="body m-before-square mt-10">Wharton will provide a listing of courses during the following academic year by mid-November, at the latest.</p>
                        </div>

                        <h3 class="m-title type01 mt-20">Course Add</h3>
                        <div class="bodies">
                            <p class="body m-before-square mt-10">
                                Students may add a course through the first week of the fall or spring semester with consent of the course instructor.
                                (The add period during the summer term is shortened to one-half week.) A $20 late registration fee will be added
                                to the tuition cost of the course.
                            </p>
                        </div>

                        <h3 class="m-title type01 mt-20">
                            Course Drop
                        </h3>
                        <div class="bodies">
                            <p class="body m-before-square mt-10">
                                Students may drop a course without penalty through the fourth week of the fall or spring semester.
                                (The drop period is shortened to two weeks during the summer term.) If the student's school has a different drop period,
                                the shorter of the two periods will be enforced.
                            </p>
                            <p class="body m-before-square">
                                The student's parent/guardian or a local high school official needs to inform the course instructor and the Wharton superintendent
                                that the student is withdrawing from a course.
                            </p>
                            <p class="body m-before-square">
                                The superintendent will drop the student from the course. If the student's school has a policy that students cannot
                                drop a course after a certain number of weeks into a course, Wharton will abide by that policy.
                            </p>
                            <p class="body m-before-square">
                                If the student is allowed to withdraw from a course after the drop period a grade of WP (withdrew passing) or WF
                                (withdrew failing), depending on the student's grade on work due by the time of the drop, will be issued by the course
                                instructor to the student's local school. It is expected that the local school will process this grade according to their
                                already existing policies for other courses at their school.
                            </p>
                        </div>

                        <h3 class="m-title type01 mt-20">
                            AP Exams
                        </h3>
                        <div class="bodies">
                            <p class="body m-before-square mt-10">
                                Wharton is registered with the College Board as an online course provider. All AP courses offered through Wharton are fully
                                authorized by the College Board on an annual basis. Wharton cannot administer AP Exams directly. Students wishing to take
                                an AP Exam need to do so at a site, often a local high school, that is authorized to order and administer the exam. Check
                                with your local school administration to see if they are an authorized site.
                            </p>
                            <p class="body m-before-square">
                                The College Board offers specific instructions on how to proceed if you do not attend a local school that is authorized
                                to administer an AP Exam.
                            </p>
                        </div>

                        <h3 class="m-title type01 mt-20">Instructors</h3>
                        <div class="bodies">
                            <p class="body m-before-square mt-10">
                                Wharton employs credentialed teachers and highly qualified teachers under No Child Left Behind (NCLB) who provide a high level
                                of student support. All instructors hold current teaching credentials, and many also possess masters and doctoral degrees.
                                All teachers have also been trained. The faculty and curriculum developers understand the unique paradigm of online education
                                and are well-versed in providing personal one-on-one attention students need to be successful online.
                            </p>
                        </div>

                        <!-- 수정필요 #2 -->
                        <a href="/file/handbook.pdf" class="m-btn type02 mt-20">
                            Download School Handbook
                            <img src="/img/download-primary.png" alt="">
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    data(){
        return {
            form: this.$inertia.form({
                grades: "9-12",
                first_name: null,
                last_name: null,
                phone: null,
                email: null,
                state: null,
                post_code: null,
                comment: null,
            })
        }
    },

    methods: {
        store(){
            this.form.post("/requestCourseInformations", {
                preserveScroll: true,
                onSuccess: (response) => {
                    alert(response.props.flash.success);

                    this.form.reset();
                }
            })
        }
    },

    mounted(){
        AOS.init();
    }
}
</script>
