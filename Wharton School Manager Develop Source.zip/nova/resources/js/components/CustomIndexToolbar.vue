<template>
  <div class="flex w-full justify-end items-center mx-3" />
</template>

<script>
export default {
  props: ['resourceName'],
}
</script>
