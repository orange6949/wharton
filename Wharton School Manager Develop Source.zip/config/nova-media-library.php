<?php

return [
    'enable-existing-media' => false,
];
